from __future__ import print_function

import os

import pytest
import logging


@pytest.fixture(scope='session')
def globalFixture():
    print("{:-^90}".format(str("(Running 1st-part of Global Fixture)")))
    yield
    print("{:-^90}".format(str("(Running 2nd-part of Global Fixture)")))


@pytest.fixture(scope='function')
def globalFixture1():
    print("{:-^60}".format(str("(Running 1st-part of Global Fixture1)")))
    yield
    print("{:-^60}".format(str("(Running 2nd-part of Global Fixture1)")))


# @pytest.fixture
# def logIt():
# log = logging.getLogger()


# def pytest_logger_config(logger_config):
# logger_config.add_loggers(['foo', 'bar'], stdout_level='info')
# logger_config.set_log_option_default('foo', 'bar')


def pytest_logger_logdirlink(config):
    return os.path.join(os.path.dirname(__file__), 'mylogs')
