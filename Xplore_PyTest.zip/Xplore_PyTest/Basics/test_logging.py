import pytest
from _pytest import logging


def test_bar1():
    print("boom")
    pass


def test_bar2():
    print("boom")
    pass


@pytest.mark.mpi
def test_bar3():
    print("boom")
    pass
