import logging

import pytest
import allure

logging.basicConfig(format='|%(asctime)s| [%(levelname)s] (%(module)s::%(funcName)s::%(lineno)d) => {%(msg)s}',
                    datefmt='%a %d-%b-%Y %H:%M:%S', level=logging.DEBUG)


@allure.step("1")
def test_success():
    """This method is for Success"""
    log = logging.getLogger(__name__)
    log.info("jhgj")
    print("Success")
    assert True


@allure.step("2") 
def test_failure():
    """This method is for Failure"""
    print("Failure")
    assert False


@allure.step("3")
def test_skip():
    """This method is for Skip"""
    print("Skip")
    pytest.skip()


@allure.step("4")
def test_exception():
    """This method is for Exception"""
    print("Exception")
    raise Exception('oops')
