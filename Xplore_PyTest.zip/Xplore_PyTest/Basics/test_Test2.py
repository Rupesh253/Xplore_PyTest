import pytest


@pytest.fixture(scope="session")
def localFixture():
    print("\n.....Local Fixture")


def test_PrintTempDir(tmpdir):
    print(tmpdir)


def test_Method1WithoutAnyFixtureInTest2():
    print("Method1 in Test2")


def test_Method2WithoutAnyFixtureInTest2():
    print("Method2 in Test2")


def test_Method3WithLocalFixtureInTest2(localFixture):
    print("Method3 in Test2")


# def test_Method4WithGlobalFixtureInTest2(globalFixture):
# print("Method4 in Test2")


@pytest.mark.category1
def test_Method5WithMarkersInTest2():
    print("Method5 in Test1")


@pytest.mark.category2
def test_Method6WithMarkersInTest2():
    print("Method6 in Test1")
