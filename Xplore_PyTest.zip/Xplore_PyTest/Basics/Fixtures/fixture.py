import pytest


@pytest.fixture(autouse='True', scope='function')
def g_fixture():
    print("function scope fixture in Class1")
