import pytest


@pytest.fixture(scope='class')
def class2_fixture():
    print("function scope fixture in Class2")


@pytest.mark.cat1
def test_Method1(globalFixture, globalFixture1):
    print("Running test_Method1 in Class2")


@pytest.mark.cat1
def test_Method2(globalFixture, globalFixture1):
    print("Running test_Method2 in Class2")


@pytest.mark.cat1
def test_Method3(globalFixture, globalFixture1):
    print("Running test_Method3 in Class2")
