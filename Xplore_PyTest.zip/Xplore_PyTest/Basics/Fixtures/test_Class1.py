import glob
import os

import pytest


@pytest.fixture(scope='function')
def class1_fixture():
    print("function scope fixture in Class1")


@pytest.mark.parametrize('id,by', [(1, True), (2, True)])
@pytest.mark.cat1
def test_Method1(globalFixture, globalFixture1, id, by):
    path = "C:\\Users\\PycharmProjects\\Automation\\Output\\Screenshots\\Label"
    # pytest.exit("pytest_exit called")
    if os.path.isdir(path):
        print("yep exists")
    else:
        print("Nope")
        os.mkdir(path)
    assert id == by
    print("Running test_Method1 in Class1" + str(id))
    print(os.getcwd())
    dir = "C:\\Users\\PycharmProjects\\Automation\\Resources\\StandardImages\\"
    print(len(os.listdir(dir)))
    Text = os.path.abspath(
        os.path.join(os.path.dirname(dir), ""))
    print(Text)
    print(len(os.listdir(Text)))
    print(glob.glob("/StandardImages/*.jpg"))
    array = os.listdir(Text)
    print(array[0])
    if "Temp" not in array[3]:
        print("!!!!!" + os.path.abspath(
            os.path.join(os.path.dirname(array[0]), "")))
    else:
        print("@@@")


@pytest.mark.cat1
def test_Method2(globalFixture, globalFixture1):
    print("Running test_Method2 in Class1")


@pytest.mark.cat1
def test_Method3(globalFixture, globalFixture1):
    print("Running test_Method3 in Class1")
