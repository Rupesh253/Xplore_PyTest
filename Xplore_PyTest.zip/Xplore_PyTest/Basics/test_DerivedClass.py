import pytest


# from Basics.globalFixtures import Base

@pytest.mark.cat1
def test_TestMethod1(global_fixture):
    print("test_TestMethod1 with Global Fixture")


@pytest.mark.cat1
def test_TestMethod2(global_fixture):
    print("test_TestMethod2 with Global Fixture")
