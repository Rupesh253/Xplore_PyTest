import io
from io import StringIO, BytesIO
from PIL import Image, ImageChops
import PIL
import extcolors
from PIL.Image import Image
from pytesseract import pytesseract
from tesserocr._tesserocr import PyTessBaseAPI, RIL, iterate_level


def test_post():
    imageLocation = "C:\\Users\\PycharmProjects\\Xplore_PyTest\\contained_button.PNG"
    pytesseract.tesseract_cmd = r'C:\Program Files\Tesseract-OCR\tesseract'
    print(pytesseract.image_to_string(imageLocation).encode('UTF-8'))
    print(pytesseract.image_to_string(imageLocation))
    print(pytesseract.image_to_boxes(imageLocation))
    print(pytesseract.image_to_data(imageLocation))
    # print(pytesseract.image_to_osd(imageLocation))


def test_color():
    print("\nNote: \n (0, 169, 224) = DeepSkyBlue \n (255,255,255) = White")

    """imageLocation = "C:\\Users\\PycharmProjects\\Xplore_PyTest\\contained_button.PNG"
    colors, pixel_count = extcolors.extract(imageLocation)
    print("------------------------------------------------------------")
    print("Contained Button -> DeepSkyBlue: Major and White: Minor")
    print("Colors are {0}".format(colors))
    print("Total pixel count is {0}".format(pixel_count))

    imageLocation = "C:\\Users\\PycharmProjects\\Xplore_PyTest\\outlined_button.PNG"
    colors, pixel_count = extcolors.extract(imageLocation)
    print("------------------------------------------------------------")
    print("Outlined Button -> White:Major and DeepSkyBlue:Minor")
    print("Colors are {0}".format(colors))
    print("Total pixel count is {0}".format(pixel_count))

    imageLocation = "C:\\Users\\PycharmProjects\\Xplore_PyTest\\text_button.PNG"
    colors, pixel_count = extcolors.extract(imageLocation)
    print("------------------------------------------------------------")
    print("Text Button -> White: Full Major and DeepSkyBlue:Full Minor")
    print("Colors are {0}".format(colors))
    print("Total pixel count is {0}".format(pixel_count))"""

    imageLocation = "C:\\Users\\PycharmProjects\\Xplore_PyTest\\31.PNG"
    cropimageLocation = "C:\\Users\\PycharmProjects\\Xplore_PyTest\\31_crop.jpg"
    cropCropimageLocation = "C:\\Users\\PycharmProjects\\Xplore_PyTest\\31_crop_crop.jpg"
    colors, pixel_count = extcolors.extract(imageLocation)
    print("Colors are {0}".format(colors))
    print("Total pixel count is {0}".format(pixel_count))
    im = PIL.Image.open(imageLocation)
    if im.mode in ("RGBA", "P"):
        im = im.convert("RGB")
    im.save(cropimageLocation, quality=100)
    im1 = PIL.Image.open(cropimageLocation)
    width, height = im1.size
    left = 5
    top = height / 4
    right = 164
    bottom = 3 * height / 4
    print("width:{0}, height:{1}".format(width, height))
    im2 = im1.crop((0, 0, 50, 50))
    im2.save(cropCropimageLocation)
    # im = PIL.Image.open(imageLocation).resize(5, 5)
    # im.convert("RGB").save(cropimageLocation, 'JPEG')
    # im1.show()


def test_shape():
    Rectangle_Contained = r"C:\Users\Desktop\button shapes\Rectangle_Contained.jpg"
    RoundedRectangle_Contained = r"C:\Users\Desktop\button shapes\Rounded Rectangle_Contained.jpg"
    Stadium_Contained = r"C:\Users\Desktop\button shapes\Stadium_Contained.jpg"
    SuperEllipse_Contained = r"C:\Users\Desktop\button shapes\Super Ellipse_Contained.jpg"
    Rectangle_Outlined = r"C:\Users\Desktop\button shapes\Rectangle_Outlined.jpg"
    RoundedRectangle_Outlined = r"C:\Users\Desktop\button shapes\Rounded Rectangle_Outlined.jpg"
    Stadium_Outlined = r"C:\Users\Desktop\button shapes\Stadium_Outlined.jpg"
    SuperEllipse_Outlined = r"C:\Users\Desktop\button shapes\Super Ellipse_Outlined.jpg"
    Text = r"C:\Users\Desktop\button shapes\Text.jpg"
    colors, pixel_count = extcolors.extract(Rectangle_Contained)
    print("------------------------------------------------------------")
    print("Rectangle_Contained Button -> DeepSkyBlue: Major")
    print("Colors are {0}".format(colors))
    print("Total pixel count is {0}".format(pixel_count))

    colors, pixel_count = extcolors.extract(RoundedRectangle_Contained)
    print("------------------------------------------------------------")
    print("RoundedRectangle_Contained Button -> DeepSkyBlue: Major and White: Minor")
    print("Colors are {0}".format(colors))
    print("Total pixel count is {0}".format(pixel_count))

    colors, pixel_count = extcolors.extract(Stadium_Contained)
    print("------------------------------------------------------------")
    print("Stadium_Contained Button -> DeepSkyBlue: Major and White: Minor")
    print("Colors are {0}".format(colors))
    print("Total pixel count is {0}".format(pixel_count))

    colors, pixel_count = extcolors.extract(SuperEllipse_Contained)
    print("------------------------------------------------------------")
    print("SuperEllipse_Contained Button -> DeepSkyBlue: Major and White: Minor")
    print("Colors are {0}".format(colors))
    print("Total pixel count is {0}".format(pixel_count))

    colors, pixel_count = extcolors.extract(Rectangle_Outlined)
    print("------------------------------------------------------------")
    print("Rectangle_Outlined Button -> DeepSkyBlue: Minor and White: Major")
    print("Colors are {0}".format(colors))
    print("Total pixel count is {0}".format(pixel_count))

    colors, pixel_count = extcolors.extract(RoundedRectangle_Outlined)
    print("------------------------------------------------------------")
    print("RoundedRectangle_Outlined Button -> DeepSkyBlue: Minor and White: Major")
    print("Colors are {0}".format(colors))
    print("Total pixel count is {0}".format(pixel_count))

    colors, pixel_count = extcolors.extract(Stadium_Outlined)
    print("------------------------------------------------------------")
    print("Stadium_Outlined Button -> DeepSkyBlue: Minor and White: Major")
    print("Colors are {0}".format(colors))
    print("Total pixel count is {0}".format(pixel_count))

    colors, pixel_count = extcolors.extract(SuperEllipse_Outlined)
    print("------------------------------------------------------------")
    print("SuperEllipse_Outlined Button -> DeepSkyBlue: Minor and White: Major")
    print("Colors are {0}".format(colors))
    print("Total pixel count is {0}".format(pixel_count))

    colors, pixel_count = extcolors.extract(Text)
    print("------------------------------------------------------------")
    print("Text Button -> White: Major")
    print("Colors are {0}".format(colors))
    print("Total pixel count is {0}".format(pixel_count))


def test_compare():
    Rectangle_Contained = r"C:\Users\Desktop\button shapes\Rectangle_Contained.jpg"
    RoundedRectangle_Contained = r"C:\Users\Desktop\button shapes\Rounded Rectangle_Contained.jpg"
    Stadium_Contained = r"C:\Users\Desktop\button shapes\Stadium_Contained.jpg"
    SuperEllipse_Contained = r"C:\Users\Desktop\button shapes\Super Ellipse_Contained.jpg"

    im = PIL.Image.open(Stadium_Contained)
    im1 = PIL.Image.open(Stadium_Contained)
    x = ImageChops.difference(im, im1).getcolors()
    y = ImageChops.difference(im, im1).getbbox()
    z = ImageChops.difference(im, im1).getbands()
    tuple1 = (0, 0, 0)
    tuple2 = x[0][1]
    if tuple1 == x[0][1]:
        print("Equal")
    print("list of colors{0}".format(x))
    print("list of colors{0}".format(x[0][1]))
    print("list of box{0}".format(y))
    print("list of bands{0}".format(z))


def test_font():
    imageLocation = "C:\\Users\\PycharmProjects\\Xplore_PyTest\\contained_button.PNG"
    pytesseract.tesseract_cmd = "C:\\Program Files\\Tesseract-OCR\\tesseract"
    with PyTessBaseAPI(path='C:\\Program Files\\Tesseract-OCR\\tessdata', ) as api:
        image = PIL.Image.open(imageLocation)
        api.SetImage(image)
        api.Recognize()  # required to get result from the next line
        iterator = api.GetIterator()
        print("\n" + str(iterator.WordFontAttributes()))
