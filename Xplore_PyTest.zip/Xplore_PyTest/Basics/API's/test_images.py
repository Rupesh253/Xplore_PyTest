import os

import PIL
from PIL import ImageChops
from playsound import playsound


def compare_images(image1, image2):
    diff_colors, diff_boxes = None, None
    try:
        diff_colors = ImageChops.difference(image1, image2).getcolors()
        diff_boxes = ImageChops.difference(image1, image2).getbbox()
        return diff_colors, diff_boxes
    except Exception as e:
        print("")


def test_1():
    StandardImagesDirectory = os.path.join(os.getcwd(), "")
    # print("StandardImagesDirectory:{0}".format(StandardImagesDirectory))
    # print(os.cpu_count())
    # print(os.ctermid())
    # print(os.confstr_names)
    # print("curdir:{0}".format(os.curdir))
    # print("chdir:{0}".format(os.chdir(os.curdir)))
    # print("defpath:{0}".format(os.defpath))
    # print("devnull:{0}".format(os.devnull))
    # print("environ:{0}".format(os.environ))
    # print("environb:{0}".format(os.environb))
    # print("error:{0}".format(os.error))
    # print("EX_CANTCREAT:{0}".format(os.EX_CANTCREAT))
    # print("EX_CONFIG:{0}".format(os.EX_CONFIG))
    # print("extsep:{0}".format(os.extsep))
    # print("F_OK:{0}".format(os.F_LOCK))
    # print("F_OK:{0}".format(os.F_OK))
    # print("F_OK:{0}".format(os.F_TEST))
    # print("F_OK:{0}".format(os.F_TLOCK))
    # print("F_OK:{0}".format(os.F_ULOCK))
    # print("getcwd:{0}".format(os.getcwd()))
    # print("getcwdb:{0}".format(os.getcwdb()))
    # print("getegid:{0}".format(os.getegid()))
    # print("geteuid:{0}".format(os.geteuid()))
    # print("getgid:{0}".format(os.getgid()))
    # print("getgroups:{0}".format(os.getgroups()))
    # print("getloadavg:{0}".format(os.getloadavg()))

    # print("name:{0}".format(os.name))
    # print("getcwd:{0}".format(os.confstr_names))
    # print("getcwd:{0}".format(os.pathconf_names))
    print("realpath:{0}".format(os.path.realpath(os.path.join(os.getcwd(), "../."))))
    print("abspath:{0}".format(os.path.abspath(os.path.join(os.getcwd(), "../"))))
    # print("name:{0}".format(os.name))
    # print("name:{0}".format(os.name))
    playsound(r"C:\Users\Downloads\smb_mariodie.wav")


def test_image():
    StandardImagesDirectory = r"C:\Users\PycharmProjects\Automation\Resources\StandardImages"
    print("StandardImagesDirectory:{0}".format(StandardImagesDirectory))
    standardImagesArray = os.listdir(StandardImagesDirectory)
    totalImagesCount = len(standardImagesArray)
    print("totalImagesCount:{0}".format(totalImagesCount))
    croppedjpgImageLocation = r"C:\Users\PycharmProjects\Xplore_PyTest\31_crop_crop.jpg"
    image1 = PIL.Image.open(croppedjpgImageLocation)

    for x in range(totalImagesCount - 1):
        print("standardImagesArray[{0}]:{1}".format(x, standardImagesArray[x]))
        if "Temp" not in standardImagesArray[x] and "CropTemp" not in standardImagesArray[x]:
            image2Location = StandardImagesDirectory + "\\" + standardImagesArray[x]
            # image2Location = os.path.abspath(
            # os.path.join(os.path.dirname(StandardImagesDirectory), standardImagesArray[x]))
            print("Image2:{0}".format(image2Location))
            image2 = PIL.Image.open(image2Location)
            diff_colors, diff_boxes = compare_images(image1, image2)
            if diff_boxes is None:
                if diff_colors == [(2500, (0, 0, 0))]:
                    array = standardImagesArray[x].replace(".jpg", "").split('_')
                    button_shape, button_type = array[0], array[1]
                    print("button_shape:{0} \n button_type:{1}".format(button_shape, button_type))
                    break
