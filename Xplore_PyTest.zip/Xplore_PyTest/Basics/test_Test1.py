import pytest


@pytest.fixture(scope="function")
def localFixture():
    print("\n(Running Local Fixture)")


def test_MethodWithoutAnyFixture():
    print("\n\t<MethodWithoutAnyFixture>")


def test_MethodWithGlobalFixture(globalFixture):
    print("\t<MethodWithGlobalFixture>")


def test_MethodWithLocalFixture(localFixture):
    print("\t<MethodWithLocalFixture>")


def test_MethodWithGlobalAndLocalFixture(globalFixture, localFixture):
    print("\t<MethodWithGlobalAndLocalFixture>")


def test_MethodWithLocalAndGlobalFixture(localFixture, globalFixture):
    print("\t<MethodWithLocalAndGlobalFixture>")


@pytest.mark.category1
def test_MethodWithCategory1():
    print("\n\t<MethodWithCategory1>")


@pytest.mark.category2
def test_MethodWithCategory2():
    print("\n\t<MethodWithCategory2>")


@pytest.mark.category3
@pytest.mark.parametrize("input1,input2,output", [(1, 2, 3), (4, 5, 9), (7, 8, 15)])
def test_MethodWithParametrizationAndCategory(input1, input2, output):
    assert input1 + input2 == output, "Assertion Failure"
    print("Successful Assertion")
