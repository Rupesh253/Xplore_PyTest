import psutil
import requests
import pytest


def test_all():
    response = requests.get("https://www.google.com/maps/", None)
    print(response)
    for pid in psutil.pids():
        environ = psutil.Process(pid).environ()
        if "PYTEST_CURRENT_TEST" in environ:
            print(f'pytest process {pid} running: {environ["PYTEST_CURRENT_TEST"]}')