import logging

import pytest


def test_PrintTempDir(tmpdir):
    print("tmpdir: " + str(tmpdir))


def test_PrintTempPath(tmp_path):
    print("tmpPath: " + str(tmp_path))


def test_PrintTempFactory(tmp_path_factory):
    print("tmp_path_factory: " + str(tmp_path_factory))


def test_TempDirFactory(tmpdir_factory):
    print("tmpdir_factory: " + str(tmpdir_factory))


def test_DoctestNamespace(doctest_namespace):
    print("doctest_namespace: " + str(doctest_namespace))


def test_PytestConfig(pytestconfig):
    print("pytestconfig: " + str(pytestconfig))


def test_Recwarn(recwarn):
    print("recwarn: " + str(recwarn))


def test_CapLog(caplog):
    print("caplog: " + str(caplog))


def test_RecordProperty(record_property):
    record_property("OS_Name", "OSName")
    record_property("OS_Version", "OSVersion")
    print("record_property: " + str(record_property))


def test_RecordTestSuiteProperty(record_testsuite_property):
    record_testsuite_property("Suite_Name", "SuiteName")
    record_testsuite_property("Suite_Number", "SuiteNumber")
    print("RecordTestSuiteProperty")


def test_RecordXmlAttribute(record_xml_attribute):
    record_xml_attribute("XMl_Attribute", "XMlAttribute")
    print("RecordXmlAttribute")


def test_CaptureLogs(caplog):
    caplog.set_level(logging.INFO, logger="Will log this")


@pytest.fixture(scope="session", autouse=True)
def test_FixtureMethod():
    print("Local Fixture Method in testing of Inbuilt fixtures")


def test_FixturedMethod(test_FixtureMethod):
    print("Fixtured Method in testing of Inbuilt fixtures")


def test_NormalMethod():
    print("Normal Method in testing of Inbuilt fixtures")
