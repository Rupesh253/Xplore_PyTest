import logging
import os

logging.basicConfig(format='|%(asctime)s| [%(levelname)s] (%(module)s::%(funcName)s::%(lineno)d) => {%(msg)s}',
                    datefmt='%a %d-%b-%Y %H:%M:%S', level=logging.DEBUG)


def test_1():
    log = logging.getLogger(__name__)
    log.info('{:-^50}'.format('START'))
    log.info(os.path.abspath(os.curdir))
    log.info(os.path.abspath(__name__))
    log.info(os.path.abspath(__file__))
    log.info('info')
    log.warning('warning')
    log.fatal('fatal')
    log.error('error')
    log.debug('debug')
    log.critical('critical')
    log.exception('exception')
    log.info('{:-^50}'.format('END'))
