import logging
import os

currentDirectory = os.path.abspath(os.curdir)
logFilePath = os.path.join(currentDirectory, 'log.log')
logging.basicConfig(filename=logFilePath, format='|%(asctime)s| [%(levelname)s] [%(module)s::%(funcName)s():%('
                                                 'lineno)d] '
                                                 '=> {%(msg)s}',
                    datefmt='%a %d/%b/%Y %H:%M:%S', level=logging.DEBUG)


def getobjvar(type, value):
    try:
        if type is 'rid':
            objectvar = {'rid': value, 'name': '', 'xpath': '', 'aid': ''}
        elif type is 'name':
            objectvar = {'rid': '', 'name': value, 'xpath': '', 'aid': ''}
        elif type is 'xpath':
            objectvar = {'rid': '', 'name': '', 'xpath': value, 'aid': ''}
        elif type is 'aid':
            objectvar = {'rid': '', 'name': '', 'xpath': '', 'aid': value}
        else:
            return None

        return objectvar
    except Exception as e:
        return None


def test_1():
    log = logging.getLogger(__name__)
    log.info('{:-^85}'.format('START of class:' + str(__name__)) + ' ')
    log.info(os.path.abspath(os.curdir))
    log.info(os.path.abspath(__name__))
    log.info(os.path.abspath(__file__))
    log.info('info')
    log.warning('warning')
    log.fatal('fatal')
    log.error('error')
    log.debug('debug')
    log.critical('critical')
    log.exception('exception')
    obj = getobjvar('xpath', 'xpath')
    print(str(obj))

    log.info('{:-^85}'.format('END'))
