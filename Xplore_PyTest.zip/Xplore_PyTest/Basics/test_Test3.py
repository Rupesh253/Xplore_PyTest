import pytest


@pytest.mark.category1
class Test3:
    def test_EntireClassTestsCategorizationForTest3(self):
        print("EntireClassTestsCategorization")


def test_PrintTempDir(tmpdir):
    print(tmpdir)


@pytest.mark.category2
class Test4:
    def test_EntireClassTestsCategorizationForTest4(self):
        print("EntireClassTestsCategorization")


class Test5:
    # @pytest.mark.env("SAT")
    def test_SAT(self):
        print("SAT")

    # @pytest.mark.env("UAT")
    def test_UAT(self):
        print("UAT")

    # @pytest.mark.env("PROD")
    def test_PROD(self):
        print("PROD")
