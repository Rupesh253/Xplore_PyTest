import os

import allure
import pytest
import pytest_bdd
from _pytest import logging
import logging

pytest_bdd.scenarios('C:/Users/PycharmProjects/Xplore_PyTest/Advanced/BDD/Features/feature1.feature', )

# @scenario('feature1.feature', 'Feature1', features_base_dir='./BDD/Features/')
# def test_feature():
# pass

currentDirectory = os.path.abspath(os.curdir)
logFilePath = os.path.join(currentDirectory, 'log.log')
logging.basicConfig(filename=logFilePath, format='|%(asctime)s| [%(levelname)-8s] [%(module)s::%(funcName)s():%('
                                                 'lineno)d] '
                                                 '=> {%(msg)s}',
                    datefmt='%a %d/%b/%Y %H:%M:%S', level=logging.DEBUG)


@pytest.fixture
def preRequisite():
    print("Pre-Common method")


@allure.epic('Epic1')
@allure.feature('Feature1')
@allure.suite('Suite1')
@allure.id('Id1')
@allure.tag('Tag1')
@allure.description("Description1")
@allure.story("Story1")
@allure.severity(allure.severity_level.MINOR)
@allure.title("This is the allure title")
@allure.step("This is the allure step")
@pytest_bdd.given('given_statement')
def method1(preRequisite):
    log = logging.getLogger(__name__)
    log.info("given info")
    log.debug("given debug")
    log.fatal("given fatal")
    log.error("given error")
    log.warning("given warning")
    print("\ngiven_statement method")
    pass


@allure.epic("Epic1")
@allure.feature("Feature1")
@allure.suite("Suite1")
@allure.description("Description2")
@allure.story("Story1")
@allure.tag("Tag1")
@allure.id("Id2")
@allure.severity(allure.severity_level.NORMAL)
@allure.title("This is the allure title")
@allure.step("This is the allure step")
@pytest.mark.flaky(reruns=3)
@pytest_bdd.when("when_statement")
def method2(preRequisite):
    print("when_statement method")
    assert True


@allure.epic("Epic1")
@allure.feature("Feature1")
@allure.suite("Suite1")
@allure.story("Story1")
@allure.tag("Tag1")
@allure.id("Id3")
@allure.description("Description3")
@allure.title("This is the allure title")
@allure.step("This is the allure step")
@pytest_bdd.then("then_statement")
def method3(preRequisite):
    print("then_statement method")
    pass

    # @classmethod
    # def getSize(self, driver, obj_property):
    # ele = GenericMethods.find_element(driver, obj_property)
    # print("ele.size.width" + str(ele.size.width))
    # print("ele.size.height" + str(ele.size.height))
    # print("ele.location.x" + str(ele.location.x))
    # print("ele.location.y" + str(ele.location.y))
    # print("ele.rect.x" + str(ele.rect.x))
    # print("ele.rect.y" + str(ele.rect.y))
    # print("ele.rect.width" + str(ele.rect.width))
    # print("ele.rect.height" + str(ele.rect.height))
    # print("ele.bounds" + str(ele.get_attribute('bounds')))
